class Cadre {
  final String name;
  final DateTime createdDate;

  Cadre({
    required this.name,
    required this.createdDate,
  });
}
