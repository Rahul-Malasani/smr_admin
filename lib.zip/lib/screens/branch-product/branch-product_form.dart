import 'package:flutter/material.dart';
import 'package:smr_admin/models/branch_product.dart';
import 'package:smr_admin/models/branch.dart';
import 'package:smr_admin/models/product.dart';
import 'package:smr_admin/services/branch_service.dart';
import 'package:smr_admin/services/product_service.dart';
import 'package:smr_admin/services/branch-product_service.dart';

class BranchProductForm extends StatefulWidget {
  @override
  _BranchProductFormState createState() => _BranchProductFormState();
}

class _BranchProductFormState extends State<BranchProductForm> {
  final _formKey = GlobalKey<FormState>();

  Branch? _selectedBranch;
  Product? _selectedProduct;
  bool _isActive = true;

  @override
  Widget build(BuildContext context) {
    final branches = BranchService.getAll();
    final products = ProductService.getAll();

    return Scaffold(
      appBar: AppBar(title: const Text("Map Branch to Product")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              DropdownButtonFormField<Branch>(
                value: _selectedBranch,
                items: branches
                    .map((b) => DropdownMenuItem(
                          value: b,
                          child: Text(b.name),
                        ))
                    .toList(),
                onChanged: (val) => setState(() => _selectedBranch = val),
                decoration: const InputDecoration(labelText: "Select Branch"),
                validator: (val) =>
                    val == null ? "Branch is required" : null,
              ),
              DropdownButtonFormField<Product>(
                value: _selectedProduct,
                items: products
                    .map((p) => DropdownMenuItem(
                          value: p,
                          child: Text(p.name),
                        ))
                    .toList(),
                onChanged: (val) => setState(() => _selectedProduct = val),
                decoration: const InputDecoration(labelText: "Select Product"),
                validator: (val) =>
                    val == null ? "Product is required" : null,
              ),
              Row(
                children: [
                  const Text("Active"),
                  Checkbox(
                    value: _isActive,
                    onChanged: (val) => setState(() => _isActive = val ?? true),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    final mapping = BranchProduct(
                      branchId: _selectedBranch!.id,
                      productId: _selectedProduct!.id,
                      createdDate: DateTime.now(),
                      isActive: _isActive,
                    );
                    BranchProductService.add(mapping);

                    print(
                      "Mapping created: Branch ${_selectedBranch!.name} - Product ${_selectedProduct!.name}",
                    );

                    Navigator.pop(context);
                  }
                },
                child: const Text("Save"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
