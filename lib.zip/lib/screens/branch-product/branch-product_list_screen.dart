import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smr_admin/models/branch_product.dart';
import 'package:smr_admin/services/branch_service.dart';
import 'package:smr_admin/services/product_service.dart';
import 'package:smr_admin/services/branch-product_service.dart';
import 'package:smr_admin/screens/branch-product/branch-product_form.dart';

class BranchProductListScreen extends StatefulWidget {
  const BranchProductListScreen({super.key});

  @override
  State<BranchProductListScreen> createState() =>
      _BranchProductListScreenState();
}

class _BranchProductListScreenState extends State<BranchProductListScreen> {
  List<BranchProduct> mappings = [];

  @override
  void initState() {
    super.initState();
    mappings = BranchProductService.getAll();
  }

  void _addMapping() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (ctx) => BranchProductForm()),
    ).then((_) {
      setState(() {
        mappings = BranchProductService.getAll();
      });
    });
  }

  void _deleteMapping(BranchProduct bp) {
    BranchProductService.delete(bp.branchId, bp.productId);
    setState(() {
      mappings = BranchProductService.getAll();
    });
  }

  String _getBranchName(int id) {
    final branches = BranchService.getAll();
    return branches.firstWhere((b) => b.id == id).name;
  }

  String _getProductName(int id) {
    final products = ProductService.getAll();
    return products.firstWhere((p) => p.id == id).name;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Branch - Product Mapping")),
      body: ListView.builder(
        itemCount: mappings.length,
        itemBuilder: (ctx, i) {
          final bp = mappings[i];
          return ListTile(
            title: Text(
              "Branch: ${_getBranchName(bp.branchId)} - Product: ${_getProductName(bp.productId)}",
            ),
            subtitle: Text(
              "${bp.isActive ? "Active" : "Inactive"} • Created: ${DateFormat('dd/MM/yyyy').format(bp.createdDate)}",
            ),
            trailing: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () => _deleteMapping(bp),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addMapping,
        child: const Icon(Icons.add),
      ),
    );
  }
}
