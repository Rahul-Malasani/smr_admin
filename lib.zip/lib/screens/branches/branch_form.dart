import 'package:flutter/material.dart';
import 'package:smr_admin/utils/validators.dart';

class BranchForm extends StatefulWidget {
  @override
  _BranchFormState createState() => _BranchFormState();
}

class _BranchFormState extends State<BranchForm> {
  final _formKey = GlobalKey<FormState>();

  final _companyIdController = TextEditingController();
  final _nameController = TextEditingController();
  final _addressController = TextEditingController();
  final _gprsController = TextEditingController();
  final _openingDateController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _companyIdController,
            decoration: const InputDecoration(labelText: "Company ID"),
            validator: (value) => Validators.validateAlphanumericMinLength(value, 4),
          ),
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: "Branch Name"),
            validator: (value) => Validators.validateNameMinLength(value, 4),
          ),
          TextFormField(
            controller: _addressController,
            decoration: const InputDecoration(labelText: "Address"),
            validator: Validators.isNotEmpty,
          ),
          TextFormField(
            controller: _gprsController,
            decoration: const InputDecoration(labelText: "GPRS"),
            validator: Validators.isNotEmpty,
          ),
          TextFormField(
            controller: _openingDateController,
            decoration: const InputDecoration(labelText: "Opening Date (dd/MM/yyyy)"),
            validator: Validators.validatePastDate,
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                print("Branch created: ${_nameController.text}");
              }
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }
}
