import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smr_admin/services/branch_service.dart';
import 'package:smr_admin/models/branch.dart';

class BranchListScreen extends StatelessWidget {
  const BranchListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ✅ Get only branches for Company 100
    List<Branch> branches = BranchService.getByCompany(100);

    return Scaffold(
      appBar: AppBar(title: const Text("Branches")),
      body: ListView.builder(
        itemCount: branches.length,
        itemBuilder: (context, index) {
          final branch = branches[index];
          return ListTile(
            title: Text(branch.name),
            subtitle: Text(
              "${branch.address} • Opened: ${DateFormat('dd/MM/yyyy').format(branch.openingDate)}",
            ),
            trailing: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Contact: ${branch.contact}"),
                Text("GPRS: ${branch.gprs}"),
                Text(
                  "Closes: ${DateFormat('dd/MM/yyyy').format(branch.closingDate)}",
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
