import 'package:flutter/material.dart';
import 'package:smr_admin/utils/validators.dart';

class CadreForm extends StatefulWidget {
  @override
  _CadreFormState createState() => _CadreFormState();
}

class _CadreFormState extends State<CadreForm> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          // 👇 Here’s where you put the validator
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: "Cadre Name"),
            validator: (value) => Validators.validateNameMinLength(value, 2),
          ),

          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                print("Cadre created: ${_nameController.text}");
                // later call CadreService.add(...)
              }
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }
}
