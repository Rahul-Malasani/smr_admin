import 'package:flutter/material.dart';
import 'package:smr_admin/utils/validators.dart';
import 'package:smr_admin/models/company.dart';
import 'package:smr_admin/services/company_service.dart';
import 'package:intl/intl.dart';

class CompanyForm extends StatefulWidget {
  @override
  _CompanyFormState createState() => _CompanyFormState();
}

class _CompanyFormState extends State<CompanyForm> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _openingDateController = TextEditingController();
  final _logoController = TextEditingController();
  final _addressController = TextEditingController();
  final _contactController = TextEditingController();
  final _gprsController = TextEditingController();
  final _branchesController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: "Company Name"),
            validator: (value) => Validators.validateNameMinLength(value, 4),
          ),
          TextFormField(
            controller: _openingDateController,
            decoration: const InputDecoration(
              labelText: "Opening Date (dd/MM/yyyy)",
            ),
            validator: Validators.validatePastDate,
          ),
          TextFormField(
            controller: _logoController,
            decoration: const InputDecoration(labelText: "Logo (URL or Path)"),
            validator: Validators.isNotEmpty,
          ),
          TextFormField(
            controller: _addressController,
            decoration: const InputDecoration(labelText: "Address"),
            validator: Validators.isNotEmpty,
          ),
          TextFormField(
            controller: _contactController,
            decoration: const InputDecoration(labelText: "Contact Number"),
            validator: Validators.isValidPhone,
          ),
          TextFormField(
            controller: _gprsController,
            decoration: const InputDecoration(labelText: "GPRS"),
            validator: Validators.isNotEmpty,
          ),
          TextFormField(
            controller: _branchesController,
            decoration: const InputDecoration(labelText: "Number of Branches"),
            validator: Validators.isNotEmpty,
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                try {
                  final company = Company(
                    Cid: DateTime.now().millisecondsSinceEpoch,
                    name: _nameController.text,
                    openingDate: DateFormat("dd/MM/yyyy")
                        .parseStrict(_openingDateController.text),
                    address: _addressController.text,
                    contact: _contactController.text,
                    logo: _logoController.text,
                    gprs: _gprsController.text, // ✅ matches String type
                    noofBrs: int.parse(_branchesController.text),
                  );

                  CompanyService.add(company);

                  print("Company created: ${company.name}");
                  Navigator.pop(context);
                } catch (e) {
                  print("Error parsing values: $e");
                }
              }
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }
}
