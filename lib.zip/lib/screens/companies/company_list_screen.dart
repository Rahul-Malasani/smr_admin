import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smr_admin/services/company_service.dart';
import 'package:smr_admin/models/company.dart';

class CompanyListScreen extends StatelessWidget {
  const CompanyListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    List<Company> companies = CompanyService.getAll();

    return Scaffold(
      appBar: AppBar(title: const Text("Companies")),
      body: ListView.builder(
        itemCount: companies.length,
        itemBuilder: (context, index) {
          final company = companies[index];
          return ListTile(
            title: Text(company.name),
            subtitle: Text(
              "${company.address} • Opened: ${DateFormat('dd/MM/yyyy').format(company.openingDate)}",
            ),
            trailing: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("Contact: ${company.contact}"),
                Text("Branches: ${company.noofBrs}"),
                Text("GPRS: ${company.gprs}"), // optional, but keeps info visible
              ],
            ),
          );
        },
      ),
    );
  }
}