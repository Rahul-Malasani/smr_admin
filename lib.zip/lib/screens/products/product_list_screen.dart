import 'package:flutter/material.dart';
import 'package:smr_admin/models/product.dart';
import 'package:smr_admin/services/product_service.dart';
import 'package:smr_admin/screens/products/product_form.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  List<Product> products = [];

  @override
  void initState() {
    super.initState();
    products = ProductService.getAll();
  }

  Future<void> _openForm({Product? product}) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (ctx) => ProductForm(product: product),
      ),
    );

    if (result == true) {
      setState(() {
        products = ProductService.getAll();
      });
    }
  }

  void _deleteProduct(int id) {
    ProductService.delete(id);
    setState(() {
      products = ProductService.getAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Products")),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (ctx, i) {
          final product = products[i];
          return ListTile(
            title: Text(product.name),
            subtitle: Text(product.isActive ? "Active" : "Inactive"),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _openForm(product: product), // ✅ edit
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _deleteProduct(product.id),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _openForm(), // ✅ add
        child: const Icon(Icons.add),
      ),
    );
  }
}
