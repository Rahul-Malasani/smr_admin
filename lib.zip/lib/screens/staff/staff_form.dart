import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smr_admin/utils/validators.dart';
import 'package:smr_admin/models/staff.dart';
import 'package:smr_admin/services/staff_service.dart';

class StaffForm extends StatefulWidget {
  @override
  _StaffFormState createState() => _StaffFormState();
}

class _StaffFormState extends State<StaffForm> {
  final _formKey = GlobalKey<FormState>();

  final _nameController = TextEditingController();
  final _cadreController = TextEditingController();
  final _dojController = TextEditingController();
  final _contact1Controller = TextEditingController();
  final _contact2Controller = TextEditingController();
  final _addressController = TextEditingController();          // ✅ New
  final _parentsAddressController = TextEditingController();
  final _experienceController = TextEditingController();
  final _dobController = TextEditingController();
  final _qualificationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Add Staff")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: "Name"),
                validator: (value) => Validators.validateNameMinLength(value, 3),
              ),
              TextFormField(
                controller: _cadreController,
                decoration: const InputDecoration(labelText: "Cadre"),
                validator: Validators.isNotEmpty,
              ),
              TextFormField(
                controller: _dojController,
                decoration: const InputDecoration(labelText: "Date of Joining (dd/MM/yyyy)"),
                validator: Validators.validatePastDate,
              ),
              TextFormField(
                controller: _contact1Controller,
                decoration: const InputDecoration(labelText: "Primary Contact"),
                validator: Validators.isValidPhone,
              ),
              TextFormField(
                controller: _contact2Controller,
                decoration: const InputDecoration(labelText: "Secondary Contact"),
                validator: (value) =>
                    value == null || value.isEmpty ? null : Validators.isValidPhone(value),
              ),
              TextFormField(
                controller: _addressController,                   // ✅ Address field
                decoration: const InputDecoration(labelText: "Address"),
                validator: Validators.isNotEmpty,
              ),
              TextFormField(
                controller: _parentsAddressController,
                decoration: const InputDecoration(labelText: "Parents Address"),
                  validator: Validators.isNotEmpty,
              ),
              TextFormField(
                controller: _experienceController,
                decoration: const InputDecoration(labelText: "Experience (years)"),
                validator: Validators.isValidExperience,
              ),
              TextFormField(
                controller: _dobController,
                decoration: const InputDecoration(labelText: "Date of Birth (dd/MM/yyyy)"),
                validator: Validators.validatePastDate,
              ),
              TextFormField(
                controller: _qualificationController,
                decoration: const InputDecoration(labelText: "Qualification"),
                validator: Validators.isNotEmpty,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    try {
                      final staff = Staff(
                        id: DateTime.now().millisecondsSinceEpoch,
                        branchId: 101, // dummy for now; later from context
                        name: _nameController.text,
                        cadre: _cadreController.text,
                        doj: _dojController.text,
                        contact1: _contact1Controller.text,
                        contact2: _contact2Controller.text.isEmpty ? null : _contact2Controller.text,
                        parentsAddress: _parentsAddressController.text,
                        experience: int.parse(_experienceController.text),
                        dob: DateFormat("dd/MM/yyyy").parseStrict(_dobController.text), // ✅ parsed
                        qualification: _qualificationController.text,
                      );

                      StaffService.add(staff); // ✅ save to service

                      print("Staff created: ${staff.name}");
                      Navigator.pop(context);
                    } catch (e) {
                      print("Error saving staff: $e");
                    }
                  }
                },
                child: const Text("Save"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
