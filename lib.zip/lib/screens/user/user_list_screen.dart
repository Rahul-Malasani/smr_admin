import 'package:flutter/material.dart';
import 'package:smr_admin/models/user.dart';
import 'package:smr_admin/services/user_service.dart';
import 'package:smr_admin/screens/user/user_form.dart';

class UserListScreen extends StatefulWidget {
  const UserListScreen({super.key});

  @override
  State<UserListScreen> createState() => _UserListScreenState();
}

class _UserListScreenState extends State<UserListScreen> {
  List<User> users = [];

  @override
  void initState() {
    super.initState();
    users = UserService.getAll();
  }

  Future<void> _addUser() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (ctx) => const UserForm()),
    );
    if (result == true) {
      setState(() {
        users = UserService.getAll();
      });
    }
  }

  Future<void> _editUser(User user) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(builder: (ctx) => UserForm(user: user)),
    );
    if (result == true) {
      setState(() {
        users = UserService.getAll();
      });
    }
  }

  void _deleteUser(String id) {
    UserService.delete(id);
    setState(() {
      users = UserService.getAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Users")),
      body: ListView.builder(
        itemCount: users.length,
        itemBuilder: (ctx, i) {
          final user = users[i];
          return ListTile(
            title: Text(user.username),
            subtitle: Text(
              "${user.role} - ${user.isActive ? "Active" : "Inactive"}",
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit),
                  onPressed: () => _editUser(user),
                ),
                IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () => _deleteUser(user.id),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addUser,
        child: const Icon(Icons.add),
      ),
    );
  }
}
