import 'package:smr_admin/models/user.dart';
import 'package:smr_admin/services/user_service.dart';

class AuthService {
  static User? login(String username, String password) {
    try {
      // Look up in UserService users list
      return UserService.getAll().firstWhere(
        (u) => u.username == username && u.password == password,
      );
    } catch (e) {
      return null; // no user found
    }
  }
}
