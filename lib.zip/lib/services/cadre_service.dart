import 'package:smr_admin/models/cadre.dart';

class CadreService {
  static List<Cadre> getAll() {
    return [
      Cadre( name: "Manager", createdDate: DateTime(2015, 1, 1)),
      Cadre( name: "Officer", createdDate: DateTime(2017, 3, 15)),
      Cadre( name: "Clerk", createdDate: DateTime(2019, 11, 20)),
    ];
  }
}
