import 'package:smr_admin/models/user.dart';

class UserService {
  // Permanent fallback admin (cannot be deleted)
  static final User _defaultAdmin = User(
    id: "default_admin",
    username: "admin",
    password: "Admin@@123",
    role: "Admin",
    isActive: true,
    staffId: "SYSTEM",
  );

  // Mutable user list
  static final List<User> _users = [
    User(
      id: "john_doe",
      username: "John Doe",
      password: "Pass@@1234",
      createdAt: DateTime(2024, 1, 1),
      validUntil: DateTime(2025, 1, 1),
      isActive: true,
      role: "Admin",
      staffId: "EMP001",
    ),
    User(
      id: "jane_smith",
      username: "Jane Smith",
      password: "Hello##99",
      createdAt: DateTime(2024, 3, 15),
      validUntil: DateTime(2025, 3, 15),
      isActive: false,
      role: "DataEntry",
      staffId: "EMP002",
    ),
    User(
      id: "rohit_master",
      username: "Rohit Master",
      password: "Master**22",
      createdAt: DateTime(2024, 5, 10),
      validUntil: DateTime(2026, 5, 10),
      isActive: true,
      role: "Master",
      staffId: "EMP003",
    ),
    User(
      id: "sneha_reports",
      username: "Sneha Reports",
      password: "Reports@@33",
      createdAt: DateTime(2024, 7, 1),
      validUntil: DateTime(2025, 7, 1),
      isActive: true,
      role: "Reports",
      staffId: "EMP004",
    ),
  ];

  static List<User> getAll() {
    // Always return list including default admin
    return List<User>.from([_defaultAdmin, ..._users]);
  }

  static void add(User user) {
    _users.add(user);
  }

  static void update(String id, User updatedUser) {
    final index = _users.indexWhere((u) => u.id == id);
    if (index != -1) {
      _users[index] = updatedUser;
    }
  }

  static void delete(String id) {
    if (id == "default_admin") return; // ❌ Prevent deletion of fallback admin
    _users.removeWhere((u) => u.id == id);
  }
}
